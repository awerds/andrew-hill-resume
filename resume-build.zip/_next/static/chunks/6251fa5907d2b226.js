__turbopack_load_page_chunks__("/_app", [
  "static/chunks/e60ef129113f6e24.js",
  "static/chunks/c8a542ae21335479.js",
  "static/chunks/turbopack-89db4c64206a73e4.js"
])
