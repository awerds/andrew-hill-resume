__turbopack_load_page_chunks__("/_error", [
  "static/chunks/17722e3ac4e00587.js",
  "static/chunks/c8a542ae21335479.js",
  "static/chunks/turbopack-a5b8235fa59d7119.js"
])
